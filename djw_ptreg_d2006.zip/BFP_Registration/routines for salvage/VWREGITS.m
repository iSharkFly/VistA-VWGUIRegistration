VWREGITS	;Portland, OR/jeb Patient Data Saving Utility for VWREG 11/23/2015 09:30
        ;V.2;;**LOCAL**;; 2015
        ;c2014 ad infiniti, BellFelder Productions(BF Productions)
	;License: See License.txt that comes with the install
        ;No Fall thru - jeb
	Q
	;
SAVE(RESULT,LDATA)    ;New patient save
        ;***********************************************************
        ;* Process                                                 *
        ;* 1. File major File 2 fields first:^2 has no semicolon(;)*
        ;* 2. Look for [Insurance] string - File that junk -       *
        ;*         NOTE: Insurance data has an empty ^2            *
        ;* 3. Look for ; or : - file those subsequent data pieces  *
        ;*                   by sub-DD (^2)(Note: uses DBS DIE     *
	;* Incoming: array in symbol LDATA(1),LDATA(N),etc.        *
        ;***********************************************************
	;W "  ;"...what we have here is FAILURE to comunikate!...",CHL
	;; TESTING
        ;K RESULT,INSUR
	;M ^TMP("DS",$J)=LDATA
	;S RESULT(0)="Merged..."
	;Q
	;; END TESTING
	;
	K RESULT,INSUR,MULT
	N DFN,DIC,DA,DR,VAR,FIELD,N,N1,X,Y,DIE
        I '$D(LDATA) S RESULT(0)="Nothing to file" S RESULT(0)="-1 : Client did not send any values" G SVX
	;Housekeeping- Upcase EVERYTHING, spit out insurance, if any
        S XDAT="LDATA" F  S XDAT=$Q(@XDAT) Q:XDAT=""  S @XDAT=$$UP^XLFSTR(@XDAT)
        S X="LDATA" F I=1:1 S X=$Q(@X) Q:X=""  S AR(I)=@X
	G EXP:+$P(@$Q(LDATA),"^",4)  ;Has a DFN        
        K LDATA
        S N=0 F  S N=$O(AR(N)) Q:'+N  I AR(N)="[INSURANCE]" D
        . K AR(N)
        . S N1=N
        . F I=1:1 S N1=$O(AR(N1)) Q:'+N1  Q:AR(N1)="^^^"  D
        .. S INSUR(I)=AR(N1)
        .. K AR(N1)
        K N1,N,XDAT
        ;End Housekeeping
        ;Check for an existing record
        S DFN=$$FIND1^DIC(2,"","M",$P(AR(1),"^",3),"","","ERR")
	G EXP:DFN  ;Found DFN, not new patient/client
        S X=$P(AR(1),"^",3),DIC="^DPT(",DIC(0)="Z" K D0 D FILE^DICN S DFN=$S(+Y>0:+Y,1:Y)
        I DFN=-1 S RESULT(0)="Filing error. Please contact jbellco65@gmail.com" G SVX
SL      L +^DPT(DFN):1 G SL:'$T
        S DIE=DIC,DA=DFN,DR="",CNTYFLAG=0,N=1 F  S N=$O(AR(N)) Q:'+N  D
        . Q:$P(AR(N),"^",2)[";"
        . Q:$P(AR(N),"^",3)="<FINISHED>"
	. Q:AR(N)[";"
        . S VAR=$P(AR(N),"^",3)
        . I VAR["(" S VAR=$S($L(VAR,"(")>2:+$P(VAR,"(",$L(VAR,"(")),$L(VAR,"(")<3:+$P(VAR,"(",2),1:VAR)
        . S FIELD=$P(AR(N),"^",2)
        . I FIELD=.117 D  Q
        .. S DR=FIELD_"////^S X=VAR"
        .. D ^DIE
	. IF FIELD=.09 S DA=DFN D PSEU^DGRPDD1 S VAR=L
        . S DR=FIELD_"///^S X=VAR"
        . D ^DIE
SUL     L -^DPT(DFN)
	D FHRN,,INSUR,NPSM
	S RESULT(0)="Filed..." 
SVX	Q
	;
NPSM	;File any multiples values
	Q:'$O(AR)
	S XV="AR" F  S XV=$Q(@XV) Q:XV=""  D:@XV[":"
	. S VAR=@XV
	. S DFN=$S($G(DFN):DFN,1:$P(VAR,"^",2))
	. S (SUBLABEL,SUBD,SUBF,SUBV,SUBP,PARENT,SUBN,SUBL)=""
	. S SUBLABEL=$P(VAR,"(")
	. S SUBD=+$P(VAR,"(",2)
	. S SUBF=+$P(VAR,";",2)
	. S SUBV=$P($P(VAR,":",2),"^") S:SUBV["(" SUBP=+$P(SUBV,"(",2)
	. S PARENT=$O(^DD(2,"SB",SUBD,0))
	. S SUBN=$P($P(^DD(2,PARENT,0),"^",4),";"),SUBL=$P($P(^(0),"^",4),";",2)
	. S DIC="^DPT("_DFN_","_SUBN_",",DIC(0)="L"
	. S X=$S(+SUBP:SUBP,1:SUBV),DA($O(DA(" "),-1)+1)=DFN,DA=""
	. D FILE^DICN
	Q
	;
EXP	;Existing Patient
	K X,FNAME,FFLD,FVALUE,AR,DIC,DA,DR,DIE
	S X="LDATA" F  S X=$Q(@X) Q:X=""  I @X[":" S AR($O(AR(" "),-1)+1)=@X K @X
	S N=0 F  S N=$O(LDATA(N)) Q:'+N  S X=LDATA(N) D
	. S FNAME=$P(X,"^")
	. S FFLD=$P(X,"^",2)
	. S FVALUE=$S($P(X,"^",3)["(":+$P(X,"(",2),1:$P(X,"^",3))
	. S DFN=$P(X,"^",4)
	. S DIE="^DPT(",DA=DFN,DR=FFLD_"///^S X=FVALUE" D ^DIE
	D NPSM
	S RESULT($$INR^VWREGIT)="Filed..."
	K X,FNAME,FFL,FVALUE,DFN,AR,DIE,DA,DR,DIC
	Q
	;
FHRN	;File HRN in 9000001
	G HRN:$D(^AUPNPAT(DFN))
	S DIC="^AUPNPAT(",X=DFN,DINUM=X,DIC(0)="L" D FILE^DICN
	Q:+Y<0
	S DIE=DIC,DA=DFN,DR=.02_"////^S X=DT" D ^DIE
	S DR=.11_"////^S X=DUZ" D ^DIE
HRN	S INST=$S($G(DUZ(2)):DUZ(2),1:1)
	S HRN=$G(^DPT(DFN,"648HRN"))
	Q:'$L(HRN)
	S HRN=$TR(HRN," !@#$%^&*()_+=-}{][':;>,<.?/|\","")
	Q:$D(^AUPNPAT("D",HRN))  ;HRN already there
	S DA($O(DA(" "),-1)+1)=DFN
	S (DIE,DIC)="^AUPNPAT("_DFN_",41,",DIC(0)="L",X=INST D FILE^DICN
	S DA=+Y
	I $L(HRN) S VAR=HRN,DR=.02_"///^S X=VAR" D ^DIE
	K DIC,DIE,DR,DA,HRN,INST,AUPNDAYS,AUPNDOB,AUPNDOD,AUPNPAT,AUPNSEX
	S RESULT(1)="IHS Filed..."
	Q
	;
INSUR	;Insurance data
	Q
	;
KILLIT	Q:'$G(DA)
	S:'$L(DIK) DIK="^DPT("
	D ^DIK
	Q

