VWREGIT3	;VWEHR/BFProd-Jim Bell, et al - World VistA GUI Pat Reg Utility
	;;1.0;WORLD VISTA;** **;;Build 26
	;
	;This routine utility is for patient specific fields and
	;is used to build input templates for registration
	;
	;GNU License: See WVLIC.txt
	;Modified FOIA VISTA,
	;Copyright 2013 WorldVistA.  Licensed under the terms of the GNU
	Q
	;
