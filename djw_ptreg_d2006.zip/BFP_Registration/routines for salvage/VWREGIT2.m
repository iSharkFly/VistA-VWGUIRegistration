VWREGIT2	;VWEHR/Jim Bell, et al... - Post-Install for VWREG
	;;1.0;WORLD VISTA;**HOME **;;Build 26
	;
	;Continued from VWREGIT
	;
	;GNU License: See WVLIC.txt
	;Modified FOIA VISTA,
	;Copyright 2013 WorldVistA.  Licensed under the terms of the GNU
	Q
	;
PI	;Post Installation install
	;; NOTE: The parameter definition is installed but there is no installation for
	;;the actual parameter and value. Do it here.
	;parameter value attempt
	;Set a home directory for editing; SYSTEM (DIC(4,) and DOMAIN (DIC(4.2,) only:"/home/vista/regparam/"
	S PARD=$O(^XTV(8989.51,"B","VW GUI REG TEMPLATE DIRECTORY",0))
	I PARD D
	. L +^XTV(8989.5,0):1 D  L -^XTV(8989.5,0)
	.. S NEW=$O(^XTV(8989.5," "),-1)+1
	.. S $P(^XTV(8989.5,0),"^",3)=NEW
	.. S $P(^XTV(8989.5,0),"^",4)=$P(^(0),"^",4)+1
	.. S $P(^XTV(8989.5,NEW,0),"^")="1;DIC(4,"
	.. S $P(^XTV(8989.5,NEW,0),"^",2)=PARD
	.. S $P(^XTV(8989.5,NEW,0),"^",3)=1
	.. S ^XTV(8989.5,NEW,1)="/home/vista/regparam/"
	.. S DA=NEW,DIK="^XTV(8989.5," D IX^DIK
	.. S NEW2=$O(^XTV(8989.5," "),-1)+1
	.. S $P(^XTV(8989.5,0),"^",3)=NEW2
	.. S $P(^XTV(8989.5,0),"^",4)=$P(^(0),"^",4)+1
	.. S $P(^XTV(8989.5,NEW2,0),"^")="9;DIC(4.2,"
	.. S $P(^XTV(8989.5,NEW2,0),"^",2)=PARD
	.. S $P(^XTV(8989.5,NEW2,0),"^",3)=1
	.. S ^XTV(8989.5,NEW2,1)="/home/vista/regparam/"
	.. S DA=NEW2,DIK="^XTV(8989.5," D IX^DIK
	.. ;S ^XTV(8989.5,"AC",PARD,"1;DIC(4,",1)="/home/vista/regparam/"
	.. ;S ^XTV(8989.5,"AC",PARD,"1;DIC(4,",1,NE)=""
	.. ;S ^XTV(8989.5,"B","1;DIC(4,",NE)=""
	;
	;Mailgroup VW REG ERROR REPORT - add programmer's email
	S DA(1)=$O(^XMB(3.8,"B","VW REG ERROR REPORT",0))
	Q:'DA(1)
	S DIC="^XMB(3.8,"_DA(1)_",6,"
	S X="jbellco65@gmail.com"
	S DIC(0)="LZ"
	D FILE^DICN
	Q
	;
